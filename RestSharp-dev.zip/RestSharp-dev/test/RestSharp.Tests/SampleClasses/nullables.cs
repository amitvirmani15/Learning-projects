﻿using System;

namespace RestSharp.Tests.SampleClasses
{
    public class NullableValues
    {
        public int? Id { get; set; }

        public DateTime? StartDate { get; set; }

        public Guid? UniqueId { get; set; }
    }
}